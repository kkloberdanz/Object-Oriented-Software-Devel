public class Matrix  {
  // Matrix will need additional members for instance variable and constructor
  public double[] getRow(int rownum) {
    // return the specified row of current matrix
    }
  public void swap(int rowA, int rowB) {
    // change current matrix by swapping rows rowA and rowB
    }
  public int maxRow(int column_num) {
    // looking only at column column_num in matrix,
    // return index of which row has largest value
    }
  public void scaleRow(int rownum, double factor) {
    // multiply all elements of current matrix in row rownum by factor
    }
  }
